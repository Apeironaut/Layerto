import { GridBackdrop } from '../../components/ui/GridBackdrop'
import { ThemeToggle } from '../../components/ui/ThemeToggle'
import type { Theme } from '../../hooks/useTheme'
import { LogoHero } from './components/LogoHero'

interface Props {
    theme: Theme
    onToggleTheme: () => void
}

export function LandingPage({ theme, onToggleTheme }: Props) {
    return (
        <div className="relative min-h-svh overflow-hidden bg-page bg-[radial-gradient(circle_at_50%_45%,var(--color-glow)_0,transparent_48%)] transition-colors duration-500">
            <GridBackdrop className="mask-[radial-gradient(circle_at_center,black,transparent_69%)]" />
            <ThemeToggle theme={theme} onToggle={onToggleTheme} className="fixed top-4 right-4 z-10 sm:top-9 sm:right-11" />
            <LogoHero />
        </div>
    )
}
