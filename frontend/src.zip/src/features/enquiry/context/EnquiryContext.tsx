import { createContext, useContext, useState, type ReactNode } from 'react'
import { EnquiryModal } from '../components/EnquiryModal'

interface EnquiryContextValue {
    openEnquiry: () => void
}

const EnquiryContext = createContext<EnquiryContextValue | null>(null)

/** Owns the single enquiry modal; any descendant opens it with useEnquiry(). */
export function EnquiryProvider({ children }: { children: ReactNode }) {
    const [open, setOpen] = useState(false)

    return (
        <EnquiryContext.Provider value={{ openEnquiry: () => setOpen(true) }}>
            {children}
            <EnquiryModal open={open} onClose={() => setOpen(false)} />
        </EnquiryContext.Provider>
    )
}

export function useEnquiry() {
    const ctx = useContext(EnquiryContext)
    if (!ctx) throw new Error('useEnquiry must be used inside <EnquiryProvider>')
    return ctx
}
