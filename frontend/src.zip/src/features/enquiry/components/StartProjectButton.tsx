import { Button } from '../../../components/ui/Button'
import { useEnquiry } from '../context/EnquiryContext'

interface Props {
    label?: string
    variant?: 'primary' | 'ghost' | 'outline'
    size?: 'sm' | 'md' | 'lg'
    className?: string
}

/** Every "Start a project" CTA opens the same enquiry modal. */
export function StartProjectButton({ label = 'Start a project', ...rest }: Props) {
    const { openEnquiry } = useEnquiry()
    return (
        <Button {...rest} onClick={openEnquiry} aria-haspopup="dialog">
            {label}
        </Button>
    )
}
