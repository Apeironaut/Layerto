import { Button } from '../../../components/ui/Button'
import { CheckCircleIcon } from '../../../components/ui/icons'
import { site } from '../../../config/site'
import type { SubmitResult } from '../api/submitEnquiry'

interface Props {
    name: string
    result: SubmitResult | null
    onClose: () => void
}

export function EnquirySuccess({ name, result, onClose }: Props) {
    return (
        <div role="status" className="py-4 text-center">
            <CheckCircleIcon className="mx-auto size-14 text-brand" />
            <h3 className="mt-4 mb-2 font-display text-2xl font-bold">Thanks, {name}.</h3>
            <p className="mx-auto mb-6 max-w-sm leading-relaxed text-muted">
                {result?.via === 'api'
                    ? 'We received your project details and will reply within two working days.'
                    : `Your email app should have opened with everything filled in. If it didn't, write to ${site.contactEmail}.`}
            </p>
            <Button onClick={onClose}>Close</Button>
        </div>
    )
}
