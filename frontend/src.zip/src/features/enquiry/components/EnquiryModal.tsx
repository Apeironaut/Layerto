import { Modal } from '../../../components/ui/Modal'
import { EnquiryForm } from './EnquiryForm'

interface Props {
    open: boolean
    onClose: () => void
}

export function EnquiryModal({ open, onClose }: Props) {
    return (
        <Modal open={open} onClose={onClose} title="Start a project" description="Tell us what you need. We reply within two working days.">
            {open && <EnquiryForm onDone={onClose} />}
        </Modal>
    )
}
