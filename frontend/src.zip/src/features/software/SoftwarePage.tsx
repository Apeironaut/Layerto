import { useEffect } from 'react'
import { GridBackdrop } from '../../components/ui/GridBackdrop'
import { site } from '../../config/site'
import type { Theme } from '../../hooks/useTheme'
import { loadStylesheet } from '../../lib/loadStylesheet'
import { EnquiryProvider } from '../enquiry/context/EnquiryContext'
import { AboutSection } from './components/AboutSection'
import { ContactSection } from './components/ContactSection'
import { HeroSection } from './components/HeroSection'
import { ProcessSection } from './components/ProcessSection'
import { ServicesSection } from './components/ServicesSection'
import { SiteFooter } from './components/SiteFooter'
import { SiteNav } from './components/SiteNav'
import { TeamSection } from './components/TeamSection'

interface Props {
    theme: Theme
    onToggleTheme: () => void
}

export default function SoftwarePage({ theme, onToggleTheme }: Props) {
    useEffect(() => {
        document.title = 'Layerto Software — Custom software, built in layers'
        loadStylesheet('font-display', site.fonts.display)
    }, [])

    return (
        <div className="relative min-h-svh overflow-x-clip bg-page bg-[radial-gradient(60rem_40rem_at_85%_10%,var(--color-glow),transparent_60%)] text-ink">
            <GridBackdrop className="h-svh mask-[linear-gradient(black,transparent)]" />
            <EnquiryProvider>
                <SiteNav theme={theme} onToggleTheme={onToggleTheme} />
                <main>
                    <HeroSection />
                    <ServicesSection />
                    <ProcessSection />
                    <AboutSection />
                    <TeamSection />
                    <ContactSection />
                </main>
                <SiteFooter />
            </EnquiryProvider>
        </div>
    )
}
