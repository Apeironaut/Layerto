import { Card } from '../../../components/ui/Card'
import { Section } from '../../../components/ui/Section'
import { processSteps } from '../data/process'

export function ProcessSection() {
    return (
        <Section id="process" title="How a project runs">
            <ol className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {processSteps.map((step, i) => (
                    <Card as="li" key={step.title} className="overflow-hidden">
                        {/* Red progress line draws across when the section reveals */}
                        <span
                            aria-hidden="true"
                            style={{ transitionDelay: `${i * 180 + 200}ms` }}
                            className="absolute top-0 left-0 h-1 w-full origin-left scale-x-0 bg-brand transition-transform duration-700 ease-spring group-data-[in=true]/section:scale-x-100"
                        />
                        <span className="font-display text-5xl leading-none font-bold text-brand">{i + 1}</span>
                        <h3 className="mt-6 mb-2 text-xl font-semibold">{step.title}</h3>
                        <p className="leading-relaxed text-muted">{step.body}</p>
                    </Card>
                ))}
            </ol>
        </Section>
    )
}
