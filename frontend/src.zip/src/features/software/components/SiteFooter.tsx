import { site } from '../../../config/site'
import { cn } from '../../../lib/cn'
import { container } from '../../../lib/layout'

export function SiteFooter() {
    return (
        <footer className="border-t border-line">
            <div className={cn(container, 'flex justify-between py-6 text-sm text-muted')}>
            <span>© {new Date().getFullYear()} {site.name}</span>
            <a href={`mailto:${site.contactEmail}`} className="hover:text-brand">{site.contactEmail}</a>
            </div>
        </footer>
    )
}
