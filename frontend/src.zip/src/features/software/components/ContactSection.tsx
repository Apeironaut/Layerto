import { Card } from '../../../components/ui/Card'
import { Section } from '../../../components/ui/Section'
import { site } from '../../../config/site'
import { StartProjectButton } from '../../enquiry/components/StartProjectButton'

export function ContactSection() {
    return (
        <Section id="contact" className="pt-0 sm:pt-0">
            <Card variant="inverted" padding="lg" className="overflow-hidden">
                {/* Brand glow in the corner */}
                <div aria-hidden="true" className="pointer-events-none absolute -top-40 -right-40 size-[28rem] rounded-full bg-brand/35 blur-3xl" />
                <div className="relative grid items-end gap-8 lg:grid-cols-[1fr_auto]">
                    <div>
                        <h2 className="mb-4 font-display text-4xl leading-none font-bold tracking-tight sm:text-6xl">Have something to build?</h2>
                        <p className="max-w-xl text-lg leading-relaxed opacity-70">
                            Tell us what it needs to do. We reply within two working days with questions or a rough estimate.
                        </p>
                    </div>
                    <div className="flex flex-col items-start gap-3 lg:items-end">
                        <StartProjectButton size="lg" />
                        <a href={`mailto:${site.contactEmail}`} className="text-sm opacity-70 hover:text-brand hover:opacity-100">
                            or email {site.contactEmail}
                        </a>
                    </div>
                </div>
            </Card>
        </Section>
    )
}
