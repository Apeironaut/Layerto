import { Card } from '../../../components/ui/Card'
import { Heading } from '../../../components/ui/Heading'
import { LayersIcon } from '../../../components/ui/icons'
import { Section } from '../../../components/ui/Section'
import { pillars } from '../data/pillars'

export function AboutSection() {
    return (
        <Section id="about">
            <div className="grid gap-3 lg:grid-cols-[1.1fr_0.9fr]">
                <Card padding="lg">
                    <Heading className="mb-6">About Layerto</Heading>
                    <div className="max-w-2xl space-y-5 text-lg leading-relaxed sm:text-xl">
                        <p>
                            Layerto is a team of five engineers from Sri Lanka. Our long-term work is an AI middle layer:
                            a gateway that sits between applications and language models.
                        </p>
                        <p className="text-muted">
                            Client projects fund that research, and the research makes our client work better. The same
                            engineers who build the gateway build your software.
                        </p>
                    </div>
                </Card>

                <Card variant="inverted" padding="lg">
                    <div className="mb-8 flex items-center gap-3">
                        <span className="flex size-11 items-center justify-center rounded-2xl bg-brand text-white">
                            <LayersIcon />
                        </span>
                        <h3 className="font-display text-2xl font-bold">The middle layer</h3>
                    </div>
                    <ul className="divide-y divide-page/15">
                        {pillars.map((pillar) => (
                            <li key={pillar.title} className="py-4 first:pt-0 last:pb-0">
                                <p className="font-semibold">{pillar.title}</p>
                                <p className="mt-1 text-sm leading-relaxed opacity-70">{pillar.body}</p>
                            </li>
                        ))}
                    </ul>
                </Card>
            </div>
        </Section>
    )
}
