import { Section } from '../../../components/ui/Section'
import { team } from '../data/team'
import { TeamCard } from './TeamCard'

export function TeamSection() {
    return (
        <Section id="team" title="The team" intro="Five engineers. The people you talk to are the people writing the code.">
            <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
                {team.map((member) => (
                    <TeamCard key={member.name} member={member} />
                ))}
            </ul>
        </Section>
    )
}
