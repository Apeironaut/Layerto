import type { ReactNode } from 'react'
import { Card } from '../../../components/ui/Card'
import { BrowserIcon, CloudIcon, PhoneIcon, SparkIcon, StoreIcon } from '../../../components/ui/icons'
import { Tag } from '../../../components/ui/Tag'
import { cn } from '../../../lib/cn'
import type { Service, ServiceIcon } from '../data/services'

const icons: Record<ServiceIcon, ReactNode> = {
    web: <BrowserIcon />,
    ai: <SparkIcon />,
    mobile: <PhoneIcon />,
    business: <StoreIcon />,
    cloud: <CloudIcon />,
}

export function ServiceCard({ service, className }: { service: Service; className?: string }) {
    return (
        <Card as="li" interactive className={cn('flex flex-col', className)}>
            <span className="mb-8 flex size-12 items-center justify-center rounded-2xl bg-brand/10 text-brand transition-colors duration-300 group-hover/card:bg-brand group-hover/card:text-white">
                {icons[service.icon]}
            </span>
            <h3 className="mb-2 font-display text-2xl font-bold tracking-tight">{service.title}</h3>
            <p className="mb-6 leading-relaxed text-muted">{service.body}</p>
            <div className="mt-auto flex flex-wrap gap-2">
                {service.tags.map((tag) => (
                    <Tag key={tag}>{tag}</Tag>
                ))}
            </div>
        </Card>
    )
}
