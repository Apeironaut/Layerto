import { Section } from '../../../components/ui/Section'
import { services } from '../data/services'
import { ServiceCard } from './ServiceCard'

// 6-column grid: first three cards take a third each, the last two take half each
const spans = ['lg:col-span-2', 'lg:col-span-2', 'lg:col-span-2', 'lg:col-span-3', 'lg:col-span-3']

export function ServicesSection() {
    return (
        <Section id="services" title="What we build" intro="Web, mobile, AI and the infrastructure underneath.">
            <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
                {services.map((service, i) => (
                    <ServiceCard key={service.title} service={service} className={spans[i]} />
                ))}
            </ul>
        </Section>
    )
}
