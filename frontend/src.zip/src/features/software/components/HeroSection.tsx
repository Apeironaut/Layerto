import { Button } from '../../../components/ui/Button'
import { LayerMark3D } from '../../../components/three/LayerMark3D'
import { container } from '../../../lib/layout'
import { cn } from '../../../lib/cn'
import { StartProjectButton } from '../../enquiry/components/StartProjectButton'

const headline = ['Custom software,', 'built in layers.']

export function HeroSection() {
    return (
        <section className={cn(container, 'relative grid items-center gap-8 py-12 lg:min-h-[calc(100svh-4rem)] lg:grid-cols-[1.1fr_0.9fr]')}>
            <div className="px-1 lg:pl-6">
                <h1 className="mb-6 font-display text-[clamp(2.8rem,7vw,6rem)] leading-[0.95] font-bold tracking-[-0.035em]">
                    {headline.map((line, i) => (
                        <span key={line} className="block overflow-hidden pb-[0.08em]">
                            <span className={i === 1 ? 'inline-block animate-rise text-brand [animation-delay:140ms]' : 'inline-block animate-rise'}>
                                {line}
                            </span>
                        </span>
                    ))}
                </h1>
                <p className="mb-8 max-w-xl animate-fade-up text-lg leading-relaxed text-muted [animation-delay:450ms]">
                    We design and build web apps, mobile apps and AI features for businesses in Sri Lanka and beyond.
                    Clear scope, weekly releases, code you own.
                </p>
                <div className="flex animate-fade-up flex-wrap gap-3 [animation-delay:600ms]">
                    <StartProjectButton />
                    <Button variant="ghost" href="#services">See what we build</Button>
                </div>
            </div>

            <div className="relative order-first mx-auto aspect-square w-full max-w-md lg:order-none lg:max-w-none">
                <LayerMark3D depth={1.3} angle={{ x: 0.42, y: -0.5 }} label="Layerto mark in 3D. Hover to separate the layers." className="absolute! inset-0 cursor-grab" />
                <p className="absolute bottom-[4%] left-1/2 -translate-x-1/2 text-xs text-muted pointer-coarse:hidden">Hover the mark</p>
            </div>
        </section>
    )
}
