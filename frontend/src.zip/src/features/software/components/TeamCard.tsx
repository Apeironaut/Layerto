import { Card } from '../../../components/ui/Card'
import { initials } from '../../../lib/format'
import type { TeamMember } from '../data/team'

export function TeamCard({ member }: { member: TeamMember }) {
    return (
        <Card as="li" interactive padding="sm" className="sm:p-6">
            <div className="mb-5 flex size-16 items-center justify-center overflow-hidden rounded-full bg-ink font-display text-xl font-bold text-page transition-colors duration-350 group-hover/card:bg-brand group-hover/card:text-white">
                {member.photo ? <img src={member.photo} alt="" className="size-full object-cover" /> : initials(member.name)}
            </div>
            <h3 className="mb-1 font-display text-xl font-bold">{member.name}</h3>
            <p className="mb-3 text-sm font-semibold text-brand">{member.role}</p>
            <p className="text-sm leading-relaxed text-muted">{member.focus}</p>
            {member.links && member.links.length > 0 && (
                <div className="mt-4 flex gap-4">
                    {member.links.map((link) => (
                        <a key={link.href} href={link.href} target="_blank" rel="noreferrer" className="text-sm underline underline-offset-3 hover:text-brand">
                            {link.label}
                        </a>
                    ))}
                </div>
            )}
        </Card>
    )
}
