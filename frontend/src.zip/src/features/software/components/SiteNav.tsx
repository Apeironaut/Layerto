import symbol from '../../../assets/layerto-symbol.png'
import { ThemeToggle } from '../../../components/ui/ThemeToggle'
import { site } from '../../../config/site'
import type { Theme } from '../../../hooks/useTheme'
import { cn } from '../../../lib/cn'
import { container } from '../../../lib/layout'
import { StartProjectButton } from '../../enquiry/components/StartProjectButton'

const links = [
    { href: '#services', label: 'Services' },
    { href: '#process', label: 'Process' },
    { href: '#about', label: 'About' },
    { href: '#team', label: 'Team' },
]

interface Props {
    theme: Theme
    onToggleTheme: () => void
}

export function SiteNav({ theme, onToggleTheme }: Props) {
    return (
        <header className="sticky top-0 z-20 border-b border-line bg-page/70 backdrop-blur-md">
            <div className={cn(container, 'flex items-center gap-2 py-2 sm:gap-6')}>
            <a href={site.mainUrl} className="group/brand mr-auto flex items-center gap-2 font-display text-base whitespace-nowrap sm:text-lg font-bold no-underline">
                <img src={symbol} alt="" width="26" height="30" className="transition-transform duration-400 ease-spring group-hover/brand:scale-110 group-hover/brand:-rotate-8" />
                <span>
                    Layerto <em className="font-medium text-brand not-italic">Software</em>
                </span>
            </a>

            <nav aria-label="Primary" className="mr-1 hidden items-center gap-6 md:flex">
                {links.map((l) => (
                    <a
                        key={l.href}
                        href={l.href}
                        className="relative text-sm no-underline after:absolute after:-bottom-1 after:left-0 after:h-0.5 after:w-full after:origin-right after:scale-x-0 after:bg-brand after:transition-transform after:duration-300 hover:after:origin-left hover:after:scale-x-100"
                    >
                        {l.label}
                    </a>
                ))}
            </nav>

            {/* Hero already has the CTA on small screens */}
            <div className="hidden sm:block">
                <StartProjectButton variant="outline" size="sm" />
            </div>
            <ThemeToggle theme={theme} onToggle={onToggleTheme} />
            </div>
        </header>
    )
}
