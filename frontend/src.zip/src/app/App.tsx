import { lazy, Suspense } from 'react'
import { useTheme } from '../hooks/useTheme'
import { LandingPage } from '../features/landing/LandingPage'

const SoftwarePage = lazy(() => import('../features/software/SoftwarePage'))

// software.layerto.com (or /software locally) renders the services site
const isSoftwareSite =
    window.location.hostname.startsWith('software.') || window.location.pathname.startsWith('/software')

export default function App() {
    const { theme, toggleTheme } = useTheme()

    return isSoftwareSite ? (
        <Suspense fallback={null}>
            <SoftwarePage theme={theme} onToggleTheme={toggleTheme} />
        </Suspense>
    ) : (
        <LandingPage theme={theme} onToggleTheme={toggleTheme} />
    )
}
