import type { ReactNode } from 'react'
import { cn } from '../../lib/cn'

export interface SelectOption {
    value: string
    label: string
}

interface CommonProps {
    id: string
    label: string
    value: string
    error?: string
    required?: boolean
    onChange: (value: string) => void
    onBlur?: () => void
    className?: string
}

export type ControlProps =
    | { as?: 'input'; type?: 'text' | 'email' | 'tel'; autoComplete?: string; placeholder?: string }
    | { as: 'textarea'; rows?: number; placeholder?: string }
    | { as: 'select'; options: SelectOption[] }

const controlClass =
    'w-full rounded-xl border border-line bg-surface px-3.5 py-3 text-ink transition outline-none placeholder:text-muted/70 focus:border-brand focus:ring-3 focus:ring-brand/20 aria-invalid:border-brand'

/** Labelled input / textarea / select with inline error. */
export function Field(props: CommonProps & ControlProps) {
    const { id, label, value, error, required, onChange, onBlur, className } = props
    const errorId = `${id}-error`
    const shared = {
        id,
        name: id,
        value,
        required,
        onBlur,
        'aria-invalid': Boolean(error),
        'aria-describedby': error ? errorId : undefined,
        className: controlClass,
    }

    let control: ReactNode
    if (props.as === 'textarea') {
        control = (
            <textarea
                {...shared}
                rows={props.rows ?? 5}
                placeholder={props.placeholder}
                onChange={(e) => onChange(e.target.value)}
                className={cn(controlClass, 'min-h-28 resize-y leading-relaxed')}
            />
        )
    } else if (props.as === 'select') {
        control = (
            <select {...shared} onChange={(e) => onChange(e.target.value)}>
                {props.options.map((o) => (
                    <option key={o.value} value={o.value}>
                        {o.label}
                    </option>
                ))}
            </select>
        )
    } else {
        control = (
            <input
                {...shared}
                type={props.type ?? 'text'}
                autoComplete={props.autoComplete}
                placeholder={props.placeholder}
                onChange={(e) => onChange(e.target.value)}
            />
        )
    }

    return (
        <div className={cn('flex flex-col gap-1.5', className)}>
            <label htmlFor={id} className="text-sm font-semibold">
                {label}
                {required && <span className="ml-0.5 text-brand" aria-hidden="true">*</span>}
            </label>
            {control}
            <p id={errorId} role={error ? 'alert' : undefined} className="min-h-4.5 text-xs text-brand">
                {error}
            </p>
        </div>
    )
}
