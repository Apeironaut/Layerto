import type { ReactNode } from 'react'
import { cn } from '../../lib/cn'

/** Section-level display heading (h2). */
export function Heading({ children, className }: { children: ReactNode; className?: string }) {
    return <h2 className={cn('mb-3 font-display text-4xl leading-none font-bold tracking-tight sm:text-5xl', className)}>{children}</h2>
}
