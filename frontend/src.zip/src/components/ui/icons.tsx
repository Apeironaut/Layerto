const stroke = { stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round', strokeLinejoin: 'round', fill: 'none' } as const

export function CloseIcon() {
    return (
        <svg viewBox="0 0 24 24" className="size-full" aria-hidden="true">
            <path d="M6 6l12 12M18 6L6 18" {...stroke} strokeWidth={2} />
        </svg>
    )
}

export function SunIcon() {
    return (
        <svg viewBox="0 0 24 24" className="size-4" aria-hidden="true">
            <circle cx="12" cy="12" r="3.5" {...stroke} />
            <path d="M12 2v2M12 20v2M4.93 4.93l1.42 1.42M17.65 17.65l1.42 1.42M2 12h2M20 12h2M4.93 19.07l1.42-1.42M17.65 6.35l1.42-1.42" {...stroke} />
        </svg>
    )
}

export function MoonIcon() {
    return (
        <svg viewBox="0 0 24 24" className="size-4" aria-hidden="true">
            <path d="M20 15.2A8.2 8.2 0 0 1 8.8 4a8.2 8.2 0 1 0 11.2 11.2Z" {...stroke} />
        </svg>
    )
}

export function CheckCircleIcon({ className }: { className?: string }) {
    return (
        <svg viewBox="0 0 52 52" className={className} aria-hidden="true">
            <circle cx="26" cy="26" r="23" {...stroke} strokeWidth={3} />
            <path d="M16 27l7 7 13-15" {...stroke} strokeWidth={3} pathLength={1} strokeDasharray={1} className="animate-draw" />
        </svg>
    )
}

const iconClass = 'size-6'

export function BrowserIcon() {
    return (
        <svg viewBox="0 0 24 24" className={iconClass} aria-hidden="true">
            <rect x="3" y="4" width="18" height="16" rx="3" {...stroke} />
            <path d="M3 9h18M7 6.5h.01M10 6.5h.01" {...stroke} />
        </svg>
    )
}

export function SparkIcon() {
    return (
        <svg viewBox="0 0 24 24" className={iconClass} aria-hidden="true">
            <path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3zM18.5 16l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7.7-2z" {...stroke} />
        </svg>
    )
}

export function PhoneIcon() {
    return (
        <svg viewBox="0 0 24 24" className={iconClass} aria-hidden="true">
            <rect x="6.5" y="2.5" width="11" height="19" rx="2.5" {...stroke} />
            <path d="M11 18.5h2" {...stroke} />
        </svg>
    )
}

export function StoreIcon() {
    return (
        <svg viewBox="0 0 24 24" className={iconClass} aria-hidden="true">
            <path d="M4 9.5V20h16V9.5M3 5l1.5-2h15L21 5v2.5a2.5 2.5 0 0 1-4.5 1.5 2.5 2.5 0 0 1-4.5 0 2.5 2.5 0 0 1-4.5 0A2.5 2.5 0 0 1 3 7.5V5zM9.5 20v-5h5v5" {...stroke} />
        </svg>
    )
}

export function CloudIcon() {
    return (
        <svg viewBox="0 0 24 24" className={iconClass} aria-hidden="true">
            <path d="M7 18.5a4.5 4.5 0 0 1-.6-8.96A6 6 0 0 1 18 9.2a4.7 4.7 0 0 1-.7 9.3H7z" {...stroke} />
        </svg>
    )
}

export function LayersIcon() {
    return (
        <svg viewBox="0 0 24 24" className={iconClass} aria-hidden="true">
            <path d="M12 3l9 4.5-9 4.5-9-4.5L12 3zM3 12l9 4.5 9-4.5M3 16.5L12 21l9-4.5" {...stroke} />
        </svg>
    )
}
