import type { ReactNode } from 'react'
import { useInView } from '../../hooks/useInView'
import { cn } from '../../lib/cn'
import { container } from '../../lib/layout'
import { Heading } from './Heading'

interface SectionProps {
    id?: string
    title?: string
    intro?: string
    className?: string
    headClassName?: string
    children: ReactNode
}

/**
 * Page section: shared spacing, heading and a one-time scroll reveal.
 * Children can react to the reveal with `group-data-[in=true]/section:*`.
 */
export function Section({ id, title, intro, className, headClassName, children }: SectionProps) {
    const { ref, inView } = useInView<HTMLElement>()

    return (
        <section
            ref={ref}
            id={id}
            data-in={inView}
            className={cn(
                container,
                'group/section scroll-mt-16 py-12 transition duration-900 ease-out-expo sm:py-20',
                inView ? 'translate-y-0 opacity-100' : 'translate-y-6 opacity-0',
                className,
            )}
        >
            {title && (
                <div className={cn('mb-8 max-w-2xl px-1', headClassName)}>
                    <Heading>{title}</Heading>
                    {intro && <p className="text-lg leading-relaxed text-muted">{intro}</p>}
                </div>
            )}
            {children}
        </section>
    )
}
